# Changelog

All notable changes to OttoLens.

## 1.0.7

- Rebuilt against Valheim 1.0.17. Every Harmony patch target still resolves in this build, and nothing else changed.

## 1.0.6

- Fixed status rows where a long value such as `23m 53s (1.3 days)` was drawn on top of the progress bar. The bar now shrinks to make room for the value.

## 1.0.5

- Rebuilt against Valheim 1.0.16. Every Harmony patch target still resolves in this build, and nothing else changed.

## v1.0.4

- Rebuilt against Valheim 1.0.15. Every Harmony patch target still resolves in this build, and nothing else changed.

## v1.0.3

- Rebuilt against Valheim 1.0.14. Every Harmony patch target still resolves in this build, and nothing else changed.

## v1.0.2

- `ToggleKey` is now unbound by default (was `H`). Set a key in the config to
  enable it. An existing config still on `H` is cleared once on the first
  launch after updating; bind it again if you want it back.

## v1.0.1

- Windmills, kilns, spinning wheels and eitr refineries no longer call their
  input ore. The queue meter names the input (`Barley`, `Flax`), the empty
  headline follows it (`NO BARLEY`), and the running word is `MILLING` on a
  windmill and `WORKING` on the others. Smelters and blast furnaces are
  unchanged.

## v1.0.0

- First release, for Valheim 1.0.7 and BepInEx 5.4.2350.
- One ledger panel next to the vanilla hover text, with a title, one main meter,
  up to two smaller meters, and item rows with icon, name and count.
- Readers for chests, carts and ship holds; fires, torches, braziers and hearths;
  smelters, kilns and blast furnaces; cooking stations and ovens; fermenters,
  beehives and sap collectors; plants and pickables; build pieces; rocks, trees
  and logs; item stands and armor stands; tombstones; tamed creatures; wisp
  spawners; shield generators; feasts; ground items; and crafting stations.
- Read only. OttoLens never writes to the world and never changes burn rates,
  cook times or fuel limits.
- No patch on the hover text itself, so it runs alongside other hover mods.
- Client only. No ServerSync, nothing to install on a server.
- World-placed chests stay hidden until opened once. Off with
  `HideUnopenedWorldChests`.
- Build piece status shows with the hammer out by default. `BuildPieces` can be
  `Off`, `WithHammer` or `Always`.
- `H` toggles the panel in game. Change or disable it with `ToggleKey`.
- Lens dirt is off by default, because the Eye of Odin makes all things clear.
  `RemoveLensDirt` brings it back.
